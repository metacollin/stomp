Two stomp files, zipped.
